# SKG
Here, the knowledge model V1.0 of the examples are provided in turtul syntax and the triplet data stored in the csv file.

O stands for optional metadata, M stands for mandatory metadata.
bfo:term editor(M)                 
dcterms:license(M)
rdfs:lable(M)
rdfs:comment(M)    
dcterms:created(M)
owl:versionInfo(M)
owl:priorVersion(O)
dcterms:isReplacedBy(O)
dcterms:conforms To(O)
dcterms:language(M)
dcterms:modified(M)
